package com.worknest.dao;

import com.worknest.model.User;

public interface UserDAO {
    void saveUser(User user);
    User findByEmailAndPassword(String email, String password);
}
