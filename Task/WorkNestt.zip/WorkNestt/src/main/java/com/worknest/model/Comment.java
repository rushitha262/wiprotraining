package com.worknest.model;

public class Comment {

}
