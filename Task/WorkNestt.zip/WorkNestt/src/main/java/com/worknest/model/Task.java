package com.worknest.model;

public class Task {

}
