package com.worknest.service;

import com.worknest.dao.UserDAO;
import com.worknest.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserDAO userDAO;

    @Override
    public void registerUser(User user) {
        userDAO.saveUser(user);
    }

    @Override
    public User loginUser(String email, String password) {
        return userDAO.findByEmailAndPassword(email, password);
    }
}
