package com.worknest.controller;

import com.worknest.model.User;
import com.worknest.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    // Show Register Page
    @GetMapping("/register")
    public String showRegisterForm(Model model) {
        model.addAttribute("user", new User());
        return "register";  // goes to register.jsp
    }

    // Handle Register Form
    @PostMapping("/register")
    public String registerUser(@ModelAttribute("user") User user, Model model) {
        userService.registerUser(user);
        model.addAttribute("message", "Registration successful! Please login.");
        return "login";
    }

    // Show Login Page
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";  // goes to login.jsp
    }

    // Handle Login
    @PostMapping("/login")
    public String loginUser(@RequestParam String email,
                            @RequestParam String password,
                            Model model) {
        User user = userService.loginUser(email, password);
        if (user != null) {
            model.addAttribute("user", user);
            return "dashboard"; // dashboard.jsp
        } else {
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }
    }
}
