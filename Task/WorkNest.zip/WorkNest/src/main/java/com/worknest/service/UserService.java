package com.worknest.service;

import com.worknest.model.User;
import java.util.List;

/**
 * UserService defines business operations for User entity.
 */
public interface UserService {
    void registerUser(User user);
    void updateUser(User user);
    void deleteUser(int id);
    User getUserById(int id);
    User getUserByUsername(String username);
    List<User> getAllUsers();
	User findByEmail(String email);
}
