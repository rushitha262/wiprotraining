package com.worknest.controller;

import com.worknest.model.User;
import com.worknest.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import javax.servlet.http.HttpSession;

@Controller                             // marks this as a Spring MVC controller
@RequestMapping("/auth")                // base URL for auth routes
public class AuthController {

    @Autowired
    private UserService userService;    // service to handle user logic

    // show registration page
    @GetMapping("/register")
    public String registerForm(Model model) {
        model.addAttribute("user", new User()); // empty User for form binding
        return "register";                      // resolves to /WEB-INF/views/register.jsp
    }

    // handle registration POST
    @PostMapping("/register")
    public String registerSubmit(@ModelAttribute("user") User user, Model model) {
        // basic check: existing email
        User existing = userService.findByEmail(user.getEmail());
        if (existing != null) {                 // if email exists
            model.addAttribute("error", "Email already registered");
            return "register";                  // show form again
        }
        userService.register(user);             // register user (hashes password)
        model.addAttribute("message", "Registration successful. Please login.");
        return "redirect:/auth/login";          // redirect to login page
    }

    // show login page
    @GetMapping("/login")
    public String loginForm(Model model) {
        model.addAttribute("loginEmail", "");   // placeholders
        model.addAttribute("loginPassword", "");
        return "login";                         // /WEB-INF/views/login.jsp
    }

    // process login
    @PostMapping("/login")
    public String loginSubmit(@RequestParam("email") String email,
                              @RequestParam("password") String password,
                              HttpSession session,
                              Model model) {
        User user = userService.findByEmail(email); // fetch by email
        if (user == null) {                         // not found
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }
        // check password using BCrypt
        org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder encoder =
                new org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder();
        if (!encoder.matches(password, user.getPassword())) { // password mismatch
            model.addAttribute("error", "Invalid email or password");
            return "login";
        }

        // authentication success: store minimal info in session
        session.setAttribute("loggedUserId", user.getId()); // user id
        session.setAttribute("loggedUserRole", user.getRole()); // role
        session.setAttribute("loggedUserName", user.getName()); // name

        // redirect by role to appropriate dashboard (simple example)
        if ("ADMIN".equalsIgnoreCase(user.getRole())) {
            return "redirect:/dashboard?role=admin";
        } else {
            return "redirect:/dashboard?role=user";
        }
    }

    // logout
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();                       // invalidate session
        return "redirect:/auth/login";              // go to login
    }
}
