package com.worknest.util; // Package for utility classes

// Hibernate imports
import org.hibernate.SessionFactory; // Main factory for Hibernate sessions
import org.hibernate.boot.registry.StandardServiceRegistryBuilder; // For registry configuration
import org.hibernate.cfg.Configuration; // Hibernate configuration
import org.hibernate.service.ServiceRegistry; // Service registry

/**
 * HibernateUtil is a helper class to create a singleton SessionFactory.
 * It can be used whenever we need a Hibernate session.
 */
public class HibernateUtil {

    // Static variable to hold a single instance of SessionFactory
    private static SessionFactory sessionFactory;

    // Static block initializes SessionFactory when class loads
    static {
        try {
            // Step 1: Load Hibernate configuration from hibernate.cfg.xml
            Configuration configuration = new Configuration().configure("hibernate.cfg.xml");

            // Step 2: Build ServiceRegistry from configuration
            ServiceRegistry serviceRegistry = new StandardServiceRegistryBuilder()
                    .applySettings(configuration.getProperties()).build();

            // Step 3: Build SessionFactory from ServiceRegistry
            sessionFactory = configuration.buildSessionFactory(serviceRegistry);

        } catch (Exception e) {
            e.printStackTrace(); // Print error if factory creation fails
            throw new ExceptionInInitializerError("SessionFactory creation failed: " + e);
        }
    }

    // Getter method to access the SessionFactory
    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    // Method to close SessionFactory when application shuts down
    public static void shutdown() {
        if (sessionFactory != null) {
            sessionFactory.close(); // Release resources
        }
    }
}
