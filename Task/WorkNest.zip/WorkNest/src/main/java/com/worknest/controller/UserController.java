package com.worknest.controller; // package for controllers

// Required Spring imports
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.worknest.model.Task;
import com.worknest.model.Comment;
import com.worknest.service.TaskService;
import com.worknest.service.CommentService;

/**
 * UserController handles requests for regular users (managing tasks and comments).
 */
@Controller
@RequestMapping("/user") // All requests for users will start with /user
public class UserController {

    @Autowired
    private TaskService taskService; // Inject TaskService

    @Autowired
    private CommentService commentService; // Inject CommentService

    // Show User Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("tasks", taskService.getAllTasks()); // Add all tasks
        return "user-dashboard"; // JSP file (user-dashboard.jsp)
    }

    // Show form to add new task
    @GetMapping("/add-task")
    public String addTaskForm(Model model) {
        model.addAttribute("task", new Task()); // Create empty task object
        return "task-form"; // JSP for task creation (task-form.jsp)
    }

    // Handle task form submission
    @PostMapping("/save-task")
    public String saveTask(Task task) {
        taskService.createTask(task); // Save task using service
        return "redirect:/user/dashboard"; // Redirect to dashboard
    }

    // Show comments for a task
    @GetMapping("/task/{id}/comments")
    public String showComments(@PathVariable int id, Model model) {
        model.addAttribute("comments", commentService.getCommentsByTaskId(id)); // Get comments
        model.addAttribute("taskId", id); // Add taskId for form binding
        return "comments"; // JSP file (comments.jsp)
    }

    // Handle new comment submission
    @PostMapping("/task/{id}/add-comment")
    public String addComment(@PathVariable int id, Comment comment) {
        Task task = taskService.getTaskById(id); // Get task by ID
        comment.setTask(task); // Assign task to comment
        commentService.addComment(comment); // Save comment
        return "redirect:/user/task/" + id + "/comments"; // Redirect back to comments
    }
}
