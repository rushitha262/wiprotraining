package com.worknest.dao;

import com.worknest.model.Comment;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class CommentDAOImpl implements CommentDAO {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public void saveComment(Comment comment) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.save(comment);
        tx.commit();
        session.close();
    }

    @Override
    public void updateComment(Comment comment) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        session.update(comment);
        tx.commit();
        session.close();
    }

    @Override
    public void deleteComment(int id) {
        Session session = sessionFactory.openSession();
        Transaction tx = session.beginTransaction();
        Comment comment = session.get(Comment.class, id);
        if (comment != null) {
            session.delete(comment);
        }
        tx.commit();
        session.close();
    }

    @Override
    public Comment getCommentById(int id) {
        Session session = sessionFactory.openSession();
        Comment comment = session.get(Comment.class, id);
        session.close();
        return comment;
    }

    @Override
    public List<Comment> getCommentsByTaskId(int taskId) {
        Session session = sessionFactory.openSession();
        List<Comment> comments = session.createQuery("FROM Comment WHERE task.id = :tid", Comment.class)
                                        .setParameter("tid", taskId)
                                        .list();
        session.close();
        return comments;
    }

    @Override
    public List<Comment> getCommentsByUserId(int userId) {
        Session session = sessionFactory.openSession();
        List<Comment> comments = session.createQuery("FROM Comment WHERE user.id = :uid", Comment.class)
                                        .setParameter("uid", userId)
                                        .list();
        session.close();
        return comments;
    }
}
