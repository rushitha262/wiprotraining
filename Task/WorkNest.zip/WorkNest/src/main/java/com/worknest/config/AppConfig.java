package com.worknest.config; // Package for config classes

// Spring imports
import org.springframework.context.annotation.Bean; // Used to define beans
import org.springframework.context.annotation.ComponentScan; // Enables component scanning
import org.springframework.context.annotation.Configuration; // Marks class as configuration
import org.springframework.context.annotation.Import; // To import other config classes
import org.springframework.transaction.annotation.EnableTransactionManagement; // Enable TX management

/**
 * AppConfig is the root Spring configuration class.
 * It enables component scanning, imports HibernateConfig,
 * and enables transaction management.
 */
@Configuration // Marks this as a Spring configuration class
@ComponentScan(basePackages = { "com.worknest" }) // Scans all packages under com.worknest
@EnableTransactionManagement // Enables declarative transaction management
@Import({ HibernateConfig.class }) // Imports Hibernate configuration
public class AppConfig {

    // We don’t define beans here because HibernateConfig & WebMvcConfig will handle them
    // This acts as the root configuration entry point

}
