package com.worknest.config; // Package for config classes

// Spring MVC imports
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc; // Enables Spring MVC
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry; // For static resources
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer; // Allows MVC customization
import org.springframework.web.servlet.view.InternalResourceViewResolver; // For resolving JSP pages

/**
 * WebMvcConfig configures Spring MVC.
 * It enables Web MVC, sets up view resolver, and handles static resources.
 */
@Configuration
@EnableWebMvc // Enables Spring MVC features
public class WebMvcConfig implements WebMvcConfigurer {

    // Step 1: Configure View Resolver (maps logical view names to JSP files)
    @Bean
    public InternalResourceViewResolver viewResolver() {
        InternalResourceViewResolver resolver = new InternalResourceViewResolver();

        resolver.setPrefix("/WEB-INF/views/"); // Folder containing JSP files
        resolver.setSuffix(".jsp"); // All views will end with .jsp

        return resolver;
    }

    // Step 2: Configure static resources (CSS, JS, Images)
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        // Map URL /resources/** to folder /resources/
        registry.addResourceHandler("/resources/**")
                .addResourceLocations("/resources/");
    }
}
