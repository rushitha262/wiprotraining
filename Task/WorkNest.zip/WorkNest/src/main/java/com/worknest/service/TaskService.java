package com.worknest.service;

import com.worknest.model.Task;
import java.util.List;

/**
 * TaskService defines business operations for Task entity.
 */
public interface TaskService {
    void createTask(Task task);
    void updateTask(Task task);
    void deleteTask(int id);
    Task getTaskById(int id);
    List<Task> getTasksByUserId(int userId);
    List<Task> getAllTasks();
}
