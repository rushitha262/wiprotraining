package com.worknest.util; // Package for utility classes

// Java imports
import java.security.MessageDigest; // Used for hashing
import java.security.NoSuchAlgorithmException; // Exception if algorithm not found

/**
 * PasswordEncoderUtil provides methods to hash and verify passwords.
 * It uses SHA-256 hashing to store passwords securely.
 */
public class PasswordEncoderUtil {

    // Method to encode (hash) a password using SHA-256
    public static String encodePassword(String password) {
        try {
            // Step 1: Get SHA-256 algorithm instance
            MessageDigest md = MessageDigest.getInstance("SHA-256");

            // Step 2: Apply hashing on password (converted to bytes)
            byte[] hash = md.digest(password.getBytes());

            // Step 3: Convert byte array into hexadecimal string
            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b)); // Convert each byte to hex
            }

            // Step 4: Return final hashed password
            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error: SHA-256 algorithm not found!", e);
        }
    }

    // Method to verify if entered password matches stored hashed password
    public static boolean verifyPassword(String rawPassword, String hashedPassword) {
        // Step 1: Encode entered raw password
        String encoded = encodePassword(rawPassword);

        // Step 2: Compare encoded with stored hash
        return encoded.equals(hashedPassword);
    }
}
