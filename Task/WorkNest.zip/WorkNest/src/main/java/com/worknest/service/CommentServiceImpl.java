package com.worknest.service;

import com.worknest.dao.CommentDAO;
import com.worknest.model.Comment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

/**
 * Implementation of CommentService.
 * Handles business logic for comments.
 */
@Service
@Transactional
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentDAO commentDAO;

    @Override
    public void addComment(Comment comment) {
        // Example: business logic - check if task exists before adding comment
        commentDAO.saveComment(comment);
    }

    @Override
    public void updateComment(Comment comment) {
        commentDAO.updateComment(comment);
    }

    @Override
    public void deleteComment(int id) {
        commentDAO.deleteComment(id);
    }

    @Override
    public Comment getCommentById(int id) {
        return commentDAO.getCommentById(id);
    }

    @Override
    public List<Comment> getCommentsByTaskId(int taskId) {
        return commentDAO.getCommentsByTaskId(taskId);
    }

    @Override
    public List<Comment> getCommentsByUserId(int userId) {
        return commentDAO.getCommentsByUserId(userId);
    }
}
