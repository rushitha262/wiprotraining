package com.worknest.dao;

import com.worknest.model.Task;
import java.util.List;

public interface TaskDAO {
    void saveTask(Task task);
    void updateTask(Task task);
    void deleteTask(int id);
    Task getTaskById(int id);
    List<Task> getTasksByUserId(int userId);
    List<Task> getAllTasks();
}
