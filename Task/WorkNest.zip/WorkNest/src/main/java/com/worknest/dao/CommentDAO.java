package com.worknest.dao;

import com.worknest.model.Comment;
import java.util.List;

public interface CommentDAO {
    void saveComment(Comment comment);
    void updateComment(Comment comment);
    void deleteComment(int id);
    Comment getCommentById(int id);
    List<Comment> getCommentsByTaskId(int taskId);
    List<Comment> getCommentsByUserId(int userId);
}
