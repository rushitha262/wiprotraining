package com.worknest.controller; // package for controllers

// Required Spring imports
import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.worknest.service.UserService;
import com.worknest.service.TaskService;
import com.worknest.service.CommentService;

/**
 * AdminController handles administrative functions (managing users, tasks, comments).
 */
@Controller
@RequestMapping("/admin") // All requests for admin will start with /admin
public class AdminController {

    @Autowired
    private UserService userService; // Inject UserService

    @Autowired
    private TaskService taskService; // Inject TaskService

    @Autowired
    private CommentService commentService; // Inject CommentService

    // Show Admin Dashboard
    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        model.addAttribute("users", userService.getAllUsers()); // Add all users
        model.addAttribute("tasks", taskService.getAllTasks()); // Add all tasks
        return "admin-dashboard"; // Return JSP (admin-dashboard.jsp)
    }

    // Delete a user by ID
    @GetMapping("/delete-user/{id}") // Handles /admin/delete-user/1
    public String deleteUser(@PathVariable int id) { // Extracts ID from URL
        userService.deleteUser(id); // Call service to delete user
        return "redirect:/admin/dashboard"; // Redirect back to dashboard
    }

    // Delete a task by ID
    @GetMapping("/delete-task/{id}")
    public String deleteTask(@PathVariable int id) {
        taskService.deleteTask(id); // Delete task
        return "redirect:/admin/dashboard"; // Redirect back
    }

    // Delete a comment by ID
    @GetMapping("/delete-comment/{id}")
    public String deleteComment(@PathVariable int id) {
        commentService.deleteComment(id); // Delete comment
        return "redirect:/admin/dashboard"; // Redirect back
    }
}
