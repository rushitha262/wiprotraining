package com.worknest.config; // Package for config classes

// Hibernate + JPA imports
import java.util.Properties; // To set Hibernate properties

import javax.sql.DataSource; // For database connection

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource; // Basic DataSource
import org.springframework.orm.hibernate5.HibernateTransactionManager; // Transaction manager
import org.springframework.orm.hibernate5.LocalSessionFactoryBean; // Session factory bean
import org.springframework.transaction.PlatformTransactionManager; // Interface for TX manager

/**
 * HibernateConfig manages Hibernate + Database related configurations.
 * It defines DataSource, SessionFactory, and TransactionManager.
 */
@Configuration
public class HibernateConfig {

    // Step 1: Define DataSource (database connection details)
    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();

        // Database connection properties
        dataSource.setDriverClassName("com.mysql.cj.jdbc.Driver"); // MySQL driver
        dataSource.setUrl("jdbc:mysql://localhost:3306/worknestdb?useSSL=false"); // DB URL
        dataSource.setUsername("root"); // DB username
        dataSource.setPassword("rushitha"); // DB password (change as per your system)

        return dataSource;
    }

    // Step 2: Define SessionFactory (Hibernate + entity mapping)
    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();

        // Set data source
        sessionFactory.setDataSource(dataSource());

        // Package where entity classes are located
        sessionFactory.setPackagesToScan("com.worknest.model");

        // Hibernate properties
        Properties props = new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect"); // MySQL dialect
        props.put("hibernate.show_sql", "true"); // Show SQL queries in console
        props.put("hibernate.hbm2ddl.auto", "update"); 
        // update → updates schema automatically
        // create → creates new tables every run
        // validate → validates schema without changing
        // none → does nothing

        sessionFactory.setHibernateProperties(props);

        return sessionFactory;
    }

    // Step 3: Define Transaction Manager
    @Bean
    public PlatformTransactionManager transactionManager() {
        HibernateTransactionManager transactionManager = new HibernateTransactionManager();
        transactionManager.setSessionFactory(sessionFactory().getObject()); // Attach SessionFactory
        return transactionManager;
    }
}
