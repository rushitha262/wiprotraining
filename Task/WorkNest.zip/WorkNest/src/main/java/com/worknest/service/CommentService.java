package com.worknest.service;

import com.worknest.model.Comment;
import java.util.List;

/**
 * CommentService defines business operations for Comment entity.
 */
public interface CommentService {
    void addComment(Comment comment);
    void updateComment(Comment comment);
    void deleteComment(int id);
    Comment getCommentById(int id);
    List<Comment> getCommentsByTaskId(int taskId);
    List<Comment> getCommentsByUserId(int userId);
}
